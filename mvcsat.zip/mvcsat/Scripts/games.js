﻿/*
 * 
 * Games script
 * 
 */

var listGames = [];

var $tabla = null;

$(document).ready(function () {

    alert("Ok!");
    loadTable();
    login1();
});

function login1() {
    
    var dataAjax = {
        TipoDocumento: "DNI",
        NumeroDocumento: "12345678"
    }

    

    $.ajax({
        url: '/SAT/LoginSAT',
        type: 'GET',
        dataType: 'json',
        data: dataAjax,
        success: function (e) {
            console.log(e);
           
                //dom: 'Bfrtip',
                //buttons: [{ extend: 'excel', text: "<i class='fa fa-file-excel-o'></i>  Exportar", className: 'btn-primary btn-xs' }],

            

        },
        error: function (ex) { }
    });
}

function loadTable() {

    listGames = [];
    var dataAjax = {
    }

    var xj = '{ name:"John", "age":30, "city":"New York"}';

    $.ajax({
        url: 'GetListGames',
        type: 'GET',
        dataType: 'json',
        data: dataAjax,
        success: function (e) {
            console.log(e);
            console.log(xj);
            
            
            listGames = e;

            var dataSet = listToDataSet(listGames,
                function (val) {
                    var o = [];
                    o.push(val.JuegoID);
                    o.push(val.Nombre);
                    //o.push('<a href="#" onClick="editarUsuario(' + "'" + val.IdUsuarioWeb + "'" + ')"><i data-toggle="tooltip" title="Editar Usuario" class="fa fa-edit"></i></a>&nbsp; <a href="#" onClick="eliminarUsuario(' + "'" + val.IdUsuarioWeb + "'" + ')"><i data-toggle="tooltip" title="Editar Usuario" class="fa fa-trash"></i></a>&nbsp; <a href="#" onClick="resetUsuario(' + "'" + val.IdUsuarioWeb + "'" + ')"><i data-toggle="tooltip" title="Editar Usuario" class="fa fa-refresh"></i></a>&nbsp;');
                    //o.push('<a href="#" onClick="eliminarUsuario(' + "'" + val.IdUsuarioWeb + "'" + ')"><i data-toggle="tooltip" title="Editar Usuario" class="fa fa-trash"></i></a>&nbsp;');
                    //o.push('<a href="#" onClick="resetUsuario(' + "'" + val.IdUsuarioWeb + "'" + ')"><i data-toggle="tooltip" title="Editar Usuario" class="fa fa-refresh"></i></a>&nbsp;');
                    return o;
                });

            if ($tabla !== null) {
                $tabla.destroy();
            }

            $tabla = $('#tabla').DataTable({
                data: dataSet,
                info: false,
                paging: true,
                searching: false,
                sorting: false,
                bLengthChange: false,
                columns: [
                    { title: "Id Juego" },
                    { title: "Nombre" }
                ],
                columnDefs: [
                    { width: "25%", targets: 0 },
                    { width: "75%", targets: 1 }
                ]

                //dom: 'Bfrtip',
                //buttons: [{ extend: 'excel', text: "<i class='fa fa-file-excel-o'></i>  Exportar", className: 'btn-primary btn-xs' }],

            });

        },
        error: function (ex) { }
    });

}



function listToDataSet(list, func) {
    var dataSet = [];
    var dataRow;
    if (func !== null) {
        jQuery.each(list, function (i, val) {
            var o = func(val);
            if (o[0] !== null && o[1] !== null) {
                dataSet.push(o);
            }
            return 0;
        });
    }
    return dataSet;

}
